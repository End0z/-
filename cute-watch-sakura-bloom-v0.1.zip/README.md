# Sakura Bloom · 儿童智能手表

Astro + Tailwind concept site for a children's smartwatch design system.

## Design

### Sakura Bloom · 樱花初绽

核心理念：**春天落在手腕上。**

这不是把产品简单做成粉色，而是用樱花、微风、暖白留白与克制动画建立一套完整视觉语言。

## Colors

- Sakura Pink `#F6B7C8`
- Petal `#FBE3EA`
- Warm Snow `#FFF9FA`
- Cherry `#E889A3`
- Rose Cocoa `#5B3D46`

## Run

```bash
npm install
npm run dev
```

## Next

- Real product renders
- Color theme switcher with URL state
- Responsive motion polish
- Matcha / Snow / Lemon / Starlight pages
