# 小天才儿童智能手表概念站

> Sakura Bloom · Matcha Green

## Tech Stack

- Astro
- Tailwind CSS
- TypeScript

## Themes

- `/` — Sakura Pink · 樱花粉
- `/matcha` — Matcha Green · 抹茶绿

## Design System

### Sakura Pink
- Primary `#F6B7C8`
- Petal `#FBE3EA`
- Background `#FFF9FA`
- Accent `#E889A3`

### Matcha Green
- Primary `#B7D7A8`
- Petal `#E7F1DF`
- Background `#FAFCF8`
- Accent `#7FA56F`

## Product philosophy

儿童产品，也值得被认真设计。

每个主题都通过同一套产品结构承载独立的视觉、微交互与情绪语言，保持完整产品家族的一致性。
